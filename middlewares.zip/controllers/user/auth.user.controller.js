import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import ServiceableArea from "../../models/ServiceableArea.js";
import User from "../../models/User.js";
import { sendResponse, sendError } from "../../utils/apiResponse.js";
import redis, {
    set,
    get,
    del,
    delByPattern,
} from "../../services/redisService.js";
import { generateOTP } from "../../utils/otp.js";
import { addJobToQueue, cancelJob } from "../../services/jobService.js";
import {
    generateAccessToken,
    generateRefreshToken,
} from "../../utils/token.js";
import {
    STATUS_CODES,
    ACCOUNT_STATUS,
    REFRESH_TOKEN_EXPIRY,
    ACCESS_TOKEN_EXPIRY,
    OTP_LENGTH,
    OTP_EXPIRY,
    OTP_MAX_ATTEMPTS,
    OTP_MAX_REQUESTS_PER_HOUR,
} from "../../utils/constants.js";

// CONSTANTS
const REFRESH_TOKEN_EXPIRY_SECONDS = REFRESH_TOKEN_EXPIRY * 24 * 60 * 60;
const ACCESS_TOKEN_EXPIRY_SECONDS = ACCESS_TOKEN_EXPIRY * 60;
const OTP_EXPIRY_SECONDS = OTP_EXPIRY * 60;
const OTP_RATE_LIMIT_WINDOW = 60 * 60; // 1 hour
const OTP_FAIL_WINDOW = 15 * 60; // 15 minutes
const UNVERIFIED_USER_CLEANUP_DELAY = 24 * 60 * 60 * 1000; // 24h in ms

const COOKIE_OPTIONS = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
};

// HELPERS
const setAuthCookies = (res, accessToken, refreshToken) => {
    res.cookie("accessToken", accessToken, {
        ...COOKIE_OPTIONS,
        maxAge: ACCESS_TOKEN_EXPIRY_SECONDS * 1000,
    });
    res.cookie("refreshToken", refreshToken, {
        ...COOKIE_OPTIONS,
        maxAge: REFRESH_TOKEN_EXPIRY_SECONDS * 1000,
    });
};

const clearAuthCookies = (res) => {
    res.clearCookie("accessToken", COOKIE_OPTIONS);
    res.clearCookie("refreshToken", COOKIE_OPTIONS);
};

const generateTokenPair = async (userId) => {
    const tokenId = uuidv4();

    const accessToken = generateAccessToken({
        auth_id: userId,
        type: "access",
    });

    const refreshToken = generateRefreshToken({
        auth_id: userId,
        token_id: tokenId,
        type: "refresh",
    });

    await set(
        `refresh:${userId}:${tokenId}`,
        "valid",
        "EX",
        REFRESH_TOKEN_EXPIRY_SECONDS
    );

    return { accessToken, refreshToken };
};

/**
 * Check OTP rate limit
 * @returns {boolean} true if rate limited
 */
const checkOTPRateLimit = async (phone) => {
    const rateLimitKey = `otp_rate:${phone}`;
    const count = await get(rateLimitKey);

    if (count && parseInt(count) >= OTP_MAX_REQUESTS_PER_HOUR) {
        return true;
    }

    await redis
        .multi()
        .incr(rateLimitKey)
        .expire(rateLimitKey, OTP_RATE_LIMIT_WINDOW)
        .exec();

    return false;
};

// Generate and store OTP
const generateAndStoreOTP = async (phone) => {
    const otp = generateOTP();
    const otpKey = `otp:${phone}`;

    await redis
        .multi()
        .del(otpKey)
        .set(otpKey, otp, "EX", OTP_EXPIRY_SECONDS)
        .exec();

    return otp;
};

// 1. LOGIN / REGISTER (Send OTP)
export const authUser = async (req, res) => {
    try {
        const { phone } = req.body;

        let user = await User.findOne({ phone })
            .select("status isVerified")
            .lean();

        if (user) {
            if (user.status === ACCOUNT_STATUS.BLOCKED) {
                return sendError(
                    res,
                    "Your account has been suspended. Please contact support.",
                    STATUS_CODES.FORBIDDEN
                );
            }
        } else {
            // Create new user
            user = await User.create({
                phone,
                isVerified: false,
                is_active: true,
                status: ACCOUNT_STATUS.PENDING,
            });
        }

        // Rate limit check
        const isRateLimited = await checkOTPRateLimit(phone);
        if (isRateLimited) {
            return sendError(
                res,
                "Too many OTP requests. Please try again later.",
                STATUS_CODES.TOO_MANY_REQUESTS
            );
        }

        // Generate OTP
        const otp = await generateAndStoreOTP(phone);

        // Log OTP in development only
        if (process.env.NODE_ENV === "development") {
            console.log(`[DEV] OTP for ${phone}: ${otp}`);
        }

        // Schedule cleanup of unverified users
        await cancelJob("delete-unverified-user", `delete-user-${phone}`);
        await addJobToQueue(
            "delete-unverified-user",
            { name: "delete-unverified-user", data: { phone } },
            {
                delay: UNVERIFIED_USER_CLEANUP_DELAY,
                jobId: `delete-user-${phone}`,
                removeOnComplete: true,
                removeOnFail: true,
            }
        );

        console.log("OTP", otp)

        return sendResponse({
            res,
            message: "OTP sent successfully",
            // Include OTP in dev for testing
            ...(process.env.NODE_ENV === "development" && {
                data: { otp },
            }),
        });
    } catch (err) {
        console.error("Auth User Error:", err);
        return sendError(res, "Something went wrong. Please try again.");
    }
};

// SEND OTP
export const sendOTP = async (req, res) => {
    try {
        const { phone } = req.body;

        const user = await User.findOne({ phone })
            .select("status isVerified")
            .lean();

        if (!user) {
            return sendError(
                res,
                "User not found. Please register first.",
                STATUS_CODES.NOT_FOUND
            );
        }

        if (user.status === ACCOUNT_STATUS.BLOCKED) {
            return sendError(
                res,
                "Your account has been suspended.",
                STATUS_CODES.FORBIDDEN
            );
        }

        // Rate limit check
        const isRateLimited = await checkOTPRateLimit(phone);
        if (isRateLimited) {
            return sendError(
                res,
                "Too many OTP requests. Please try again later.",
                STATUS_CODES.TOO_MANY_REQUESTS
            );
        }

        // Cooldown check — prevent rapid resends
        const cooldownKey = `otp_cooldown:${phone}`;
        const cooldownExists = await get(cooldownKey);
        if (cooldownExists) {
            return sendError(
                res,
                "Please wait before requesting another OTP.",
                STATUS_CODES.TOO_MANY_REQUESTS
            );
        }

        // Generate new OTP
        const otp = await generateAndStoreOTP(phone);

        // Set cooldown (60 seconds)
        await set(cooldownKey, "1", "EX", 60);

        // TODO: Send OTP via SMS
        if (process.env.NODE_ENV === "development") {
            console.log(`[DEV] OTP for ${phone}: ${otp}`);
        }

        return sendResponse({
            res,
            message: "OTP sent successfully",
            ...(process.env.NODE_ENV === "development" && {
                data: { otp },
            }),
        });
    } catch (err) {
        console.error("Resend OTP Error:", err);
        return sendError(res, "Failed to send OTP");
    }
};

// VERIFY OTP
export const verifyOTP = async (req, res) => {
    try {
        const { phone, otp } = req.body;
        console.log("Verifying OTP for", phone, "with OTP:", otp);
        // Check fail attempts first
        const failKey = `otp_fail:${phone}`;
        const failCount = await get(failKey);

        if (failCount && parseInt(failCount) >= OTP_MAX_ATTEMPTS) {
            await del(`otp:${phone}`);
            return sendError(
                res,
                "Too many failed attempts. Please request a new OTP.",
                STATUS_CODES.TOO_MANY_REQUESTS
            );
        }

        const user = await User.findOne({ phone })
            .select("_id status isVerified")
            .lean();

        if (!user) {
            return sendError(
                res,
                "User not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        if (user.status === ACCOUNT_STATUS.BLOCKED) {
            return sendError(
                res,
                "Your account has been suspended.",
                STATUS_CODES.FORBIDDEN
            );
        }

        // Verify OTP
        const savedOTP = await get(`otp:${phone}`);

        if (!savedOTP || savedOTP !== otp) {
            // Increment fail counter
            await redis
                .multi()
                .incr(failKey)
                .expire(failKey, OTP_FAIL_WINDOW)
                .exec();

            return sendError(
                res,
                "Invalid or expired OTP",
                STATUS_CODES.UNAUTHORIZED
            );
        }

        // OTP is valid
        await Promise.all([
            del(`otp:${phone}`),
            del(failKey),
            del(`otp_cooldown:${phone}`),
            del(`otp_rate:${phone}`),
            cancelJob("delete-unverified-user", `delete-user-${phone}`),
        ]);

        // Generate tokens
        const { accessToken, refreshToken } = await generateTokenPair(
            user._id
        );

        // Update user
        const now = new Date();
        const isFirstLogin = !user.isVerified;

        await User.findByIdAndUpdate(user._id, {
            $set: {
                isVerified: true,
                status: ACCOUNT_STATUS.ACTIVE,
                is_active: true,
                last_login_at: now,
                last_active_at: now,
            },
        });

        // Set cookies
        setAuthCookies(res, accessToken, refreshToken);

        return sendResponse({
            res,
            message: "Login successful",
            data: {
                isFirstLogin,
                needsOnboarding: isFirstLogin,
            },
        });
    } catch (err) {
        console.error("OTP Verification Error:", err);
        return sendError(res, "OTP verification failed");
    }
};

// REFRESH TOKEN
export const refreshToken = async (req, res) => {
    try {
        const token = req.cookies?.refreshToken;

        if (!token) {
            return sendError(
                res,
                "Refresh token required",
                STATUS_CODES.UNAUTHORIZED
            );
        }

        let decoded;
        try {
            decoded = jwt.verify(token, process.env.REFRESH_TOKEN_SECRET);
        } catch (jwtErr) {
            if (jwtErr.name === "TokenExpiredError") {
                return sendError(
                    res,
                    "Session expired. Please log in again.",
                    STATUS_CODES.UNAUTHORIZED
                );
            }
            return sendError(
                res,
                "Invalid refresh token",
                STATUS_CODES.UNAUTHORIZED
            );
        }

        if (decoded.type !== "refresh") {
            return sendError(
                res,
                "Invalid token type",
                STATUS_CODES.UNAUTHORIZED
            );
        }

        // Check if token exists in Redis
        const redisKey = `refresh:${decoded.auth_id}:${decoded.token_id}`;
        const exists = await get(redisKey);

        if (!exists) {
            // Possible token reuse
            await delByPattern(`refresh:${decoded.auth_id}:*`);
            clearAuthCookies(res);

            return sendError(
                res,
                "Session invalid. All sessions have been revoked for security.",
                STATUS_CODES.FORBIDDEN
            );
        }

        // Check user status
        const user = await User.findById(decoded.auth_id)
            .select("status is_active")
            .lean();

        if (!user) {
            await del(redisKey);
            clearAuthCookies(res);
            return sendError(
                res,
                "Account not found",
                STATUS_CODES.UNAUTHORIZED
            );
        }

        if (
            user.status === ACCOUNT_STATUS.BLOCKED ||
            !user.is_active
        ) {
            await del(redisKey);
            clearAuthCookies(res);
            return sendError(
                res,
                "Your account has been suspended.",
                STATUS_CODES.FORBIDDEN
            );
        }

        // Rotate tokens
        await del(redisKey);

        const { accessToken, refreshToken: newRefreshToken } =
            await generateTokenPair(decoded.auth_id);

        // Update last active
        User.findByIdAndUpdate(decoded.auth_id, {
            last_active_at: new Date(),
        }).catch((err) =>
            console.error("Failed to update last_active_at:", err)
        );

        // Set new cookies
        setAuthCookies(res, accessToken, newRefreshToken);

        return sendResponse({
            res,
            message: "Token refreshed successfully",
        });
    } catch (err) {
        console.error("Refresh Token Error:", err);
        clearAuthCookies(res);
        return sendError(
            res,
            "Session expired. Please log in again.",
            STATUS_CODES.UNAUTHORIZED
        );
    }
};

// COMPLETE PROFILE 
export const updateUserDetails = async (req, res) => {
    try {
        const { auth_id } = req.user;
        const { first_name, last_name, email, gender, dob, address, lat, lng } =
            req.body;

        // Check user exists
        const user = await User.findById(auth_id)
            .select("isSignUp status")
            .lean();

        if (!user) {
            return sendError(
                res,
                "User not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        // Prevent updating if already onboarded
        if (user.isSignUp) {
            return sendError(
                res,
                "Profile already completed. Use profile update instead.",
                STATUS_CODES.CONFLICT
            );
        }

        // Check email uniqueness
        const emailExists = await User.findOne({
            email: email.toLowerCase(),
            _id: { $ne: auth_id },
        })
            .select("_id")
            .lean();

        if (emailExists) {
            return sendError(
                res,
                "Email already in use by another account",
                STATUS_CODES.CONFLICT
            );
        }

        // Check serviceability
        const { isServiceable, serviceAreaId } =
            await checkServiceability(lat, lng);

        // Update user
        const updatedUser = await User.findByIdAndUpdate(
            auth_id,
            {
                $set: {
                    first_name: first_name.trim(),
                    last_name: last_name.trim(),
                    email: email.trim().toLowerCase(),
                    gender: gender.toLowerCase(),
                    dob: new Date(dob),
                    address: address.trim(),
                    location: {
                        type: "Point",
                        coordinates: [lng, lat],
                    },
                    isSignUp: true,
                    is_serviceable: isServiceable,
                    service_area_id: serviceAreaId,
                },
            },
            { new: true, runValidators: true }
        )
            .select("-password_hash -__v")
            .lean();

        if (!updatedUser) {
            return sendError(
                res,
                "Failed to update profile",
                STATUS_CODES.INTERNAL_SERVER_ERROR
            );
        }

        return sendResponse({
            res,
            message: "Profile completed successfully",
            data: {
                user: updatedUser,
                isServiceable,
                ...(!isServiceable && {
                    serviceMessage:
                        "Your location is not currently in our service area. You'll be notified when we expand.",
                }),
            },
        });
    } catch (err) {
        console.error("Update User Details Error:", err);
        return sendError(res, "Failed to update profile");
    }
};

// LOGOUT
export const logout = async (req, res) => {
    try {
        const token = req.cookies?.refreshToken;

        if (token) {
            const decoded = jwt.decode(token);
            if (decoded?.auth_id && decoded?.token_id) {
                await del(
                    `refresh:${decoded.auth_id}:${decoded.token_id}`
                );
            }
        }

        clearAuthCookies(res);

        return sendResponse({
            res,
            message: "Logged out successfully",
        });
    } catch (err) {
        clearAuthCookies(res);
        console.error("Logout Error:", err);
        return sendResponse({
            res,
            message: "Logged out successfully",
        });
    }
};

// Check Serviceability
const checkServiceability = async (lat, lng) => {
    try {
        // Single optimized query using $geoNear
        const results = await ServiceableArea.aggregate([
            {
                $geoNear: {
                    near: {
                        type: "Point",
                        coordinates: [lng, lat],
                    },
                    distanceField: "distance",
                    spherical: true,
                    query: { is_active: true },
                    maxDistance: 100 * 1000, // 100km max search radius in meters
                },
            },
            {
                // distance must be within area's service_radius_km
                $match: {
                    $expr: {
                        $lte: [
                            "$distance",
                            { $multiply: ["$service_radius_km", 1000] },
                        ],
                    },
                },
            },
            { $limit: 1 },
            {
                $project: {
                    _id: 1,
                    name: 1,
                    service_radius_km: 1,
                    distance: 1,
                },
            },
        ]);

        if (results.length > 0) {
            return {
                isServiceable: true,
                serviceAreaId: results[0]._id,
            };
        }

        return {
            isServiceable: false,
            serviceAreaId: null,
        };
    } catch (err) {
        console.error("Serviceability check error:", err);
        return {
            isServiceable: false,
            serviceAreaId: null,
        };
    }
};