import Driver from "../../models/Driver.js";
import ServiceableArea from "../../models/ServiceableArea.js";
import { sendResponse, sendError } from "../../utils/apiResponse.js";
import { STATUS_CODES, ACCOUNT_STATUS, REFRESH_TOKEN_EXPIRY, ACCESS_TOKEN_EXPIRY } from "../../utils/constants.js";
import redis, { set, get, del } from "../../services/redisService.js";
import { generateOTP } from "../../utils/otp.js";
import { addJobToQueue, cancelJob } from "../../services/jobService.js";
import { generateAccessToken, generateRefreshToken } from "../../utils/token.js";
import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';

// Driver authentication (login/signup) controller
export const authDriver = async (req, res) => {
    try {
        const { phone } = req.body;
        if (!phone) {
            return sendError(
                res,
                "Phone number is required",
                STATUS_CODES.BAD_REQUEST
            );
        }
        // Fetch Driver by phone
        let driver = await Driver.findOne({ phone }).select("status isVerified");
        // Existing user checks
        if (driver) {
            if (driver.status === ACCOUNT_STATUS.BLOCKED) {
                return sendResponse({
                    res,
                    message: "Inactive account. Please contact customer support.",
                    statusCode: STATUS_CODES.FORBIDDEN,
                });
            }
            if (driver.status === ACCOUNT_STATUS.PENDING && driver.is_verified === false) {
                return sendResponse({
                    res,
                    message: "Account under review. Please wait for admin approval.",
                    statusCode: STATUS_CODES.FORBIDDEN,
                });
            }
        } else {
            driver = await Driver.create({
                phone,
                isVerified: false,
                is_active: true,
                status: ACCOUNT_STATUS.PENDING
            });
        }
        // OTP handling with Redis transactions
        const otpKey = `otp:${phone}`;
        const otp = generateOTP();

        await redis.multi()
            .del(otpKey)
            .set(otpKey, otp, "EX", 120)
            .exec();

        // Manage auto-delete job
        await cancelJob("delete-unverified-driver", `delete-driver-${phone}`);
        // Schedule the new auto-delete job for the unverified driver after 24 hours
        await addJobToQueue("delete-unverified-driver", { name: "delete-unverified-driver", data: { phone } }, {
            delay: 24 * 60 * 60 * 1000,
            jobId: `delete-driver-${phone}`,
            removeOnComplete: true,
            removeOnFail: true,
        });
        console.log("otp", otp)
        return sendResponse({
            res,
            message: "OTP sent successfully",
            data: { otp },
        });

    } catch (err) {
        console.error("Driver login error:", err);
        return sendError(
            res,
            "Something went wrong. Please try again later.",
            STATUS_CODES.INTERNAL_SERVER_ERROR
        );
    }
};

// Resend OTP
export const sendOTP = async (req, res) => {
    try {
        const { phone } = req.body;
        if (!phone) return res.status(400).json({ message: "Phone required" });

        let driver = await Driver.findOne({ phone });
        if (driver && driver.is_verified) {
            return sendResponse({ res, message: "Driver already verified", statusCode: STATUS_CODES.CONFLICT });
        }

        // Delete OTP if it exists
        await redis.del(`otp:${phone}`);
        const otp = generateOTP();
        await redis.set(`otp:${phone}`, otp, "EX", 300);
        console.log("Otp is", otp)
        sendResponse({ res, data: { otp }, message: "OTP resent successfully" });
    } catch (err) {
        console.error(err);
        sendResponse({ res, message: "Failed to resend OTP", statusCode: STATUS_CODES.INTERNAL_SERVER_ERROR });
    }
};

// Verify OTP
export const verifyOTP = async (req, res) => {
    try {
        const { phone, otp } = req.body;
        const authDriver = await Driver.findOne({ phone });
        if (!authDriver || authDriver.is_verified) return sendResponse({ res, message: "Driver already verified", statusCode: STATUS_CODES.CONFLICT });

        const savedOTP = await redis.get(`otp:${phone}`);

        if (!savedOTP || savedOTP !== otp) {
            return sendResponse({ res, message: "Invalid or expired OTP", statusCode: STATUS_CODES.UNAUTHORIZED });
        }

        authDriver.is_verified = true;
        authDriver.last_login_at = new Date();
        authDriver.last_active_at = new Date();

        const tokenId = uuidv4();
        // Generate tokens
        const accessToken = generateAccessToken({
            auth_id: authDriver._id,
            type: "access",
        });
        const refreshToken = generateRefreshToken({
            auth_id: authDriver._id,
            token_id: tokenId,
            type: "refresh",
        });

        await set(
            `refresh:${authDriver._id}:${tokenId}`,
            "valid",
            "EX",
            REFRESH_TOKEN_EXPIRY
        );

        await redis.del(`otp:${phone}`);
        await cancelJob("delete-unverified-driver", `delete-driver-${phone}`);

        await Driver.findByIdAndUpdate(
            authDriver._id,
            {
                status: ACCOUNT_STATUS.ACTIVE,
                is_active: true,
                last_login_at: new Date(),
                last_active_at: new Date()
            },
            { upsert: true, new: true }
        );
        await authDriver.save();

        return sendResponse({
            res,
            data: { accessToken, refreshToken },
            message: "Login successful"
        });

    } catch (err) {
        console.error("OTP Verification Error:", err);
        return sendResponse({ res, message: "OTP verification failed", statusCode: STATUS_CODES.INTERNAL_SERVER_ERROR });
    }
};

// Refresh Token
export const refresh = async (req, res) => {
    try {
        const refreshToken = req.cookies.refreshToken;
        if (!refreshToken) {
            return sendError(res, "Refresh token missing", STATUS_CODES.UNAUTHORIZED);
        }
        const decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET);

        if (decoded.type !== "refresh") {
            return sendError(res, "Invalid refresh token", STATUS_CODES.UNAUTHORIZED);
        }

        const redisKey = `refresh:${decoded.auth_id}:${decoded.token_id}`;
        const exists = await get(redisKey);
        if (!exists) {
            return sendError(res, "Token reuse detected", STATUS_CODES.FORBIDDEN);
        }
        const authDriver = await Driver.findById(decoded.auth_id).lean();

        if (!authDriver) {
            return sendError(res, "Unauthorized", STATUS_CODES.UNAUTHORIZED);
        } else if (authDriver.status === ACCOUNT_STATUS.INACTIVE || authDriver.status === ACCOUNT_STATUS.BLOCKED) {
            return sendError(res, "Inactive Account Connect With Customer Support.", STATUS_CODES.BAD_REQUEST);
        }
        // Rotate token
        await del(redisKey);
        const newTokenId = uuidv4();

        const newRefreshToken = generateRefreshToken({
            auth_id: authDriver._id,
            token_id: newTokenId,
            type: "refresh",
        });
        await set(
            `refresh:${authDriver._id}:${newTokenId}`,
            "valid",
            "EX",
            REFRESH_TOKEN_EXPIRY
        );
        const newAccessToken = generateAccessToken({
            auth_id: authDriver._id,
            type: "access",
        });

        res.cookie("accessToken", newAccessToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "strict",
            maxAge: ACCESS_TOKEN_EXPIRY * 1000,
        });
        res.cookie("refreshToken", newRefreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "strict",
            maxAge: REFRESH_TOKEN_EXPIRY * 1000,
        });
        sendResponse({ res, message: "Token refreshed" });
    } catch (err) {
        console.error("Refresh Error:", err);
        sendError(res, "Session expired", STATUS_CODES.UNAUTHORIZED);
    }
};

// Update User Details
export const updateDriverDetails = async (req, res) => {
    try {
        const { auth_id } = req.user;
        const { first_name, last_name, email, gender, dob, address, lat, lng } = req.body;
        if (
            !first_name ||
            !last_name ||
            !email ||
            !gender ||
            !dob ||
            !address ||
            lat === undefined ||
            lng === undefined
        ) {
            return sendError(res, "Missing required fields", STATUS_CODES.BAD_REQUEST);
        }
        const driver = await Driver.findById(auth_id);
        if (!driver) {
            return sendError(res, "Driver not found", STATUS_CODES.NOT_FOUND);
        }

        // Find nearest service area
        const area = await ServiceableArea.findOne({
            is_active: true,
            location: {
                $nearSphere: {
                    $geometry: {
                        type: "Point",
                        coordinates: [lng, lat],
                    },
                    $maxDistance: 1000 * 5, // 5km safety cap
                },
            },
        });

        let isServicable = false;
        let service_area_id = null;

        if (area) {
            const geo = await ServiceableArea.aggregate([
                {
                    $geoNear: {
                        near: { type: "Point", coordinates: [lng, lat] },
                        distanceField: "dist.calculated",
                        spherical: true,
                        query: { _id: area._id },
                    },
                },
            ]);

            const distanceKm = geo[0].dist.calculated / 1000;

            if (distanceKm <= area.service_radius_km) {
                isServicable = true;
                service_area_id = area._id;
            }
        }

        // Update Driver
        driver.first_name = first_name;
        driver.last_name = last_name;
        driver.email = email;
        driver.gender = gender;
        driver.dob = dob;
        driver.address = address;
        driver.location = { type: "Point", coordinates: [lng, lat] };
        driver.isSignUp = true;
        driver.is_serviceable = isServicable;
        driver.service_area_id = service_area_id;

        await driver.save();

        return sendResponse({
            res,
            message: "Driver details updated successfully",
            data: driver,
        });

    } catch (err) {
        console.error("Driver details update error:", err);
        return sendError(res, "Something went wrong", STATUS_CODES.INTERNAL_SERVER_ERROR);
    }
};

