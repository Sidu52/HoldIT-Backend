import redis from "../../services/redisService.js";
import Driver from "../../models/Driver.js";
import { addDriverToRedis } from "../../services/driverSevices.js";

// Online Offline Driver 
export const updateDriverStatus = async (req, res) => {
    try {
        const driverId = req.user.auth_id;
        const { is_online } = req.body;
        if (typeof is_online !== "boolean") {
            return res.status(400).json({ message: "is_online must be boolean" });
        }
        const driver = await Driver.findById(driverId);
        if (!driver) {
            return res.status(404).json({ message: "Driver not found" });
        }
        driver.is_online = is_online;
        // if is_online  
        if (is_online) {
            await addDriverToRedis(driver);
        } else {
            await removeDriverFromRedis(driverId);
        }
        await driver.save();
        return res.json({ message: "Driver status updated", is_online });
    } catch (error) {
        console.error("updateDriverStatus error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};


// Change Current Location
export const updateDriverLocation = async (req, res) => {
    try {
        const driverId = req.user.auth_id;
        const { lan, lat } = req.body;

        if (!lan || !lat) {
            return res.status(400).json({ message: "Coordinates required" });
        }

        const driver = await Driver.findById(driverId);
        if (!driver) {
            return res.status(404).json({ message: "Driver not found" });
        }

        // If driver not allowed to take jobs → remove from Redis
        if (!driver.is_active || !driver.is_online) {
            await removeDriverFromRedis(driverId);
            return res.status(403).json({ message: "Driver not eligible" });
        }

        // Update MongoDB
        driver.currentLocation = {
            type: "Point",
            coordinates: [lan, lat]
        };
        driver.last_active_at = new Date();
        await driver.save();

        // Update Redis GEO
        await redis.geoadd(
            "drivers",
            lan,
            lat,
            driverId.toString()
        );

        return res.json({
            message: "Location updated",
            location: driver.currentLocation
        });

    } catch (error) {
        console.error("updateDriverLocation error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};


