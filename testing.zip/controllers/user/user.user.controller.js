// controllers/user/user.user.controller.js

import User from "../../models/User.js";
import Store from "../../models/Store.js";
import ServiceableArea from "../../models/ServiceableArea.js";
import { sendResponse, sendError } from "../../utils/apiResponse.js";
import { STATUS_CODES } from "../../utils/constants.js";
import { set, get, del } from "../../services/redisService.js";

// CONSTANTS
const PROFILE_CACHE_TTL = 300; // 5 minutes
const STORE_CACHE_TTL = 600; // 10 minutes
const EXCLUDED_FIELDS = "-password_hash -__v";

const ALLOWED_UPDATE_FIELDS = [
    "first_name",
    "last_name",
    "gender",
    "dob",
    "address",
];

// GET PROFILE
export const getProfile = async (req, res) => {
    try {
        const { auth_id } = req.user;
        const cacheKey = `user:profile:${auth_id}`;

        // Check cache
        const cached = await get(cacheKey);
        if (cached) {
            return sendResponse({
                res,
                message: "Profile fetched successfully",
                data: JSON.parse(cached),
            });
        }

        // Fetch from DB
        const user = await User.findById(auth_id)
            .select(EXCLUDED_FIELDS)
            .lean();

        if (!user) {
            return sendError(
                res,
                "User not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        // Cache result
        await set(cacheKey, JSON.stringify(user), "EX", PROFILE_CACHE_TTL);

        return sendResponse({
            res,
            message: "Profile fetched successfully",
            data: user,
        });
    } catch (err) {
        console.error("Get Profile Error:", err);
        return sendError(res, "Failed to fetch profile");
    }
};

// UPDATE PROFILE
export const updateProfile = async (req, res) => {
    try {
        const { auth_id } = req.user;

        // Build update from allowed fields
        const updates = {};
        ALLOWED_UPDATE_FIELDS.forEach((field) => {
            if (req.body[field] !== undefined) {
                updates[field] = req.body[field];
            }
        });

        // Handle location update separately
        if (req.body.lat !== undefined && req.body.lng !== undefined) {
            updates.location = {
                type: "Point",
                coordinates: [req.body.lng, req.body.lat],
            };

            // Re-check serviceability
            const { isServiceable, serviceAreaId } =
                await checkServiceability(req.body.lat, req.body.lng);

            updates.is_serviceable = isServiceable;
            updates.service_area_id = serviceAreaId;
        }

        if (Object.keys(updates).length === 0) {
            return sendError(
                res,
                "No valid fields to update",
                STATUS_CODES.BAD_REQUEST
            );
        }

        updates.updated_at = new Date();

        const updatedUser = await User.findByIdAndUpdate(
            auth_id,
            { $set: updates },
            { new: true, runValidators: true }
        )
            .select(EXCLUDED_FIELDS)
            .lean();

        if (!updatedUser) {
            return sendError(
                res,
                "User not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        // Invalidate cache
        await del(`user:profile:${auth_id}`);

        return sendResponse({
            res,
            message: "Profile updated successfully",
            data: updatedUser,
        });
    } catch (err) {
        if (err.code === 11000) {
            const field = Object.keys(err.keyPattern)[0];
            return sendError(
                res,
                `${field} already in use`,
                STATUS_CODES.CONFLICT
            );
        }

        console.error("Update Profile Error:", err);
        return sendError(res, "Failed to update profile");
    }
};

// GET NEAREST STORE
export const getNearestStore = async (req, res) => {
    try {
        const { lat, lng, max_distance = 5000 } = req.query;

        const latNum = Number(lat);
        const lngNum = Number(lng);
        const maxDist = Number(max_distance);

        // Cache key based on rounded coordinates (grid-based caching)
        const roundedLat = Math.round(latNum * 100) / 100;
        const roundedLng = Math.round(lngNum * 100) / 100;
        const cacheKey = `nearest_store:${roundedLat}:${roundedLng}:${maxDist}`;

        const cached = await get(cacheKey);
        if (cached) {
            return sendResponse({
                res,
                message: "Nearest store fetched successfully",
                data: JSON.parse(cached),
            });
        }

        // Use $geoNear for distance calculation
        const stores = await Store.aggregate([
            {
                $geoNear: {
                    near: {
                        type: "Point",
                        coordinates: [lngNum, latNum],
                    },
                    distanceField: "distance",
                    spherical: true,
                    maxDistance: maxDist,
                    query: {
                        store_is_active: true,
                        is_deleted: { $ne: true },
                    },
                },
            },
            { $limit: 5 }, // Return top 5 nearest
            {
                $project: {
                    _id: 1,
                    store_name: 1,
                    store_address: 1,
                    store_open_time: 1,
                    store_close_time: 1,
                    location: 1,
                    distance: {
                        $round: [
                            { $divide: ["$distance", 1000] },
                            2,
                        ],
                    }, // Convert to km, round 2 decimals
                },
            },
        ]);

        if (stores.length === 0) {
            return sendError(
                res,
                "No stores found near your location",
                STATUS_CODES.NOT_FOUND
            );
        }

        const responseData = {
            nearest: stores[0],
            alternatives: stores.slice(1),
            total: stores.length,
        };

        // Cache for 10 minutes
        await set(
            cacheKey,
            JSON.stringify(responseData),
            "EX",
            STORE_CACHE_TTL
        );

        return sendResponse({
            res,
            message: "Nearest store fetched successfully",
            data: responseData,
        });
    } catch (err) {
        console.error("Get Nearest Store Error:", err);
        return sendError(res, "Failed to find nearest store");
    }
};

// GET STORE BY ID
export const getStoreById = async (req, res) => {
    try {
        const { store_id } = req.params;

        const cacheKey = `store:public:${store_id}`;

        const cached = await get(cacheKey);
        if (cached) {
            return sendResponse({
                res,
                message: "Store fetched successfully",
                data: JSON.parse(cached),
            });
        }

        const store = await Store.findOne({
            _id: store_id,
            store_is_active: true,
            is_deleted: { $ne: true },
        })
            .select(
                "store_name store_address store_open_time store_close_time store_description location store_capacity"
            )
            .lean();

        if (!store) {
            return sendError(
                res,
                "Store not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        await set(
            cacheKey,
            JSON.stringify(store),
            "EX",
            STORE_CACHE_TTL
        );

        return sendResponse({
            res,
            message: "Store fetched successfully",
            data: store,
        });
    } catch (err) {
        console.error("Get Store By ID Error:", err);
        return sendError(res, "Failed to fetch store");
    }
};

// Check Serviceability
const checkServiceability = async (lat, lng) => {
    try {
        const results = await ServiceableArea.aggregate([
            {
                $geoNear: {
                    near: {
                        type: "Point",
                        coordinates: [lng, lat],
                    },
                    distanceField: "distance",
                    spherical: true,
                    query: { is_active: true },
                    maxDistance: 100 * 1000,
                },
            },
            {
                $match: {
                    $expr: {
                        $lte: [
                            "$distance",
                            { $multiply: ["$service_radius_km", 1000] },
                        ],
                    },
                },
            },
            { $limit: 1 },
            { $project: { _id: 1 } },
        ]);

        if (results.length > 0) {
            return {
                isServiceable: true,
                serviceAreaId: results[0]._id,
            };
        }

        return { isServiceable: false, serviceAreaId: null };
    } catch (err) {
        console.error("Serviceability check error:", err);
        return { isServiceable: false, serviceAreaId: null };
    }
};