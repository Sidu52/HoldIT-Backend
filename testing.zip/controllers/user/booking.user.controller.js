import mongoose from "mongoose";
import Booking from "../../models/Booking.js";
import User from "../../models/User.js";
import { sendResponse, sendError } from "../../utils/apiResponse.js";
import {
    BOOKING_STATUS,
    STATUS_CODES,
    ACCOUNT_STATUS,
} from "../../utils/constants.js";
import { addJobToQueue } from "../../services/jobService.js";
import { get, set, del, delByPattern } from "../../services/redisService.js";

// CONSTANTS
const LIST_CACHE_TTL = 60; // 1 minute
const DETAIL_CACHE_TTL = 120; // 2 minutes

// Statuses that can be cancelled
const CANCELLABLE_STATUSES = [
    BOOKING_STATUS.CREATED,
    BOOKING_STATUS.STORE_ASSIGNED,
    BOOKING_STATUS.DRIVER_SEARCH,
    BOOKING_STATUS.DRIVER_ASSIGNED,
];

// Statuses that allow return request
const RETURN_REQUESTABLE_STATUSES = [BOOKING_STATUS.STORED];

// Max active bookings per user
const MAX_ACTIVE_BOOKINGS = 5;

// Invalidate User Booking Cache
const invalidateBookingCache = async (userId, bookingId = null) => {
    try {
        const promises = [delByPattern(`user_bookings:${userId}:*`)];
        if (bookingId) {
            promises.push(del(`booking:${userId}:${bookingId}`));
        }
        await Promise.all(promises);
    } catch (err) {
        console.error("Booking cache invalidation error:", err);
    }
};

// SCHEDULE PICKUP
export const schedulePickup = async (req, res) => {
    const session = await mongoose.startSession();

    try {
        session.startTransaction();

        const userId = req.user.auth_id;
        const { pickupLocation, pickupScheduledAt, luggage, notes } = req.body;

        // Verify user
        const user = await User.findById(userId)
            .select("status is_active is_serviceable")
            .session(session)
            .lean();

        if (!user) {
            await session.abortTransaction();
            session.endSession();
            return sendError(
                res,
                "User not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        if (user.status !== ACCOUNT_STATUS.ACTIVE || !user.is_active) {
            await session.abortTransaction();
            session.endSession();
            return sendError(
                res,
                "Your account is not active",
                STATUS_CODES.FORBIDDEN
            );
        }

        if (!user.is_serviceable) {
            await session.abortTransaction();
            session.endSession();
            return sendError(
                res,
                "Your location is not in our service area",
                STATUS_CODES.FORBIDDEN
            );
        }

        // Check for existing active bookings
        const activeBookingCount = await Booking.countDocuments({
            userId,
            status: {
                $nin: [BOOKING_STATUS.DELIVERED, BOOKING_STATUS.CANCELLED],
            },
        }).session(session);

        if (activeBookingCount >= MAX_ACTIVE_BOOKINGS) {
            await session.abortTransaction();
            session.endSession();
            return sendError(
                res,
                `You can have maximum ${MAX_ACTIVE_BOOKINGS} active bookings`,
                STATUS_CODES.CONFLICT
            );
        }

        // Validate scheduled time
        const scheduledTime = new Date(pickupScheduledAt);
        const minScheduleTime = new Date(Date.now() + 30 * 60 * 1000); // At least 30 min from now

        if (scheduledTime < minScheduleTime) {
            await session.abortTransaction();
            session.endSession();
            return sendError(
                res,
                "Pickup must be scheduled at least 30 minutes from now",
                STATUS_CODES.BAD_REQUEST
            );
        }

        // Calculate total bags
        const totalBags =
            (luggage.small || 0) +
            (luggage.medium || 0) +
            (luggage.large || 0) +
            (luggage.other || 0);

        // Create booking
        const [booking] = await Booking.create(
            [
                {
                    userId,
                    status: BOOKING_STATUS.CREATED,
                    pickupLocation: {
                        type: "Point",
                        coordinates: [pickupLocation.lng, pickupLocation.lat],
                        address: pickupLocation.address || "",
                    },
                    luggage: {
                        ...luggage,
                        totalBags,
                    },
                    pickup: {
                        scheduledAt: scheduledTime,
                    },
                    notes: notes || "",
                    timeline: [
                        {
                            status: BOOKING_STATUS.CREATED,
                            note: "Booking created by user",
                            timestamp: new Date(),
                        },
                    ],
                },
            ],
            { session }
        );

        await session.commitTransaction();
        session.endSession();

        const bookingId = booking._id.toString();

        // Queue store assignment
        addJobToQueue(
            "store-assign",
            {
                name: "ASSIGN_STORE",
                data: { bookingId },
            },
            {
                jobId: `store-${bookingId}`,
                removeOnComplete: true,
                attempts: 3,
                backoff: { type: "exponential", delay: 5000 },
            }
        ).catch((err) =>
            console.error("Failed to queue store assignment:", err)
        );

        // Invalidate cache
        await invalidateBookingCache(userId);

        return sendResponse({
            res,
            statusCode: STATUS_CODES.CREATED,
            message: "Pickup scheduled successfully",
            data: {
                bookingId: booking._id,
                status: booking.status,
                scheduledAt: scheduledTime,
                totalBags,
            },
        });
    } catch (err) {
        // Safe abort
        try {
            if (session.inTransaction()) {
                await session.abortTransaction();
            }
        } catch (_) { }
        session.endSession();

        console.error("Schedule Pickup Error:", err);
        return sendError(res, "Failed to schedule pickup");
    }
};

// GET MY BOOKINGS (Paginated)
export const getMyBookings = async (req, res) => {
    try {
        const userId = req.user.auth_id;
        const {
            page = 1,
            limit = 10,
            status,
            sort_order = "desc",
        } = req.query;

        const pageNum = Number(page);
        const limitNum = Number(limit);
        const skip = (pageNum - 1) * limitNum;

        const filter = { userId };
        if (status) filter.status = status;

        // Cache key
        const cacheKey = `user_bookings:${userId}:${pageNum}:${limitNum}:${status || "all"}:${sort_order}`;

        const cached = await get(cacheKey);
        if (cached) {
            return sendResponse({
                res,
                message: "Bookings fetched successfully",
                data: JSON.parse(cached),
            });
        }

        const sortDir = sort_order === "asc" ? 1 : -1;

        const [bookings, total] = await Promise.all([
            Booking.find(filter)
                .select(
                    "status pickupLocation luggage pickup timeline createdAt notes"
                )
                .sort({ createdAt: sortDir })
                .skip(skip)
                .limit(limitNum)
                .lean(),
            Booking.countDocuments(filter),
        ]);

        const totalPages = Math.ceil(total / limitNum);

        const responseData = {
            bookings,
            pagination: {
                currentPage: pageNum,
                totalPages,
                totalItems: total,
                itemsPerPage: limitNum,
                hasNextPage: pageNum < totalPages,
                hasPrevPage: pageNum > 1,
            },
        };

        await set(
            cacheKey,
            JSON.stringify(responseData),
            "EX",
            LIST_CACHE_TTL
        );

        return sendResponse({
            res,
            message: "Bookings fetched successfully",
            data: responseData,
        });
    } catch (err) {
        console.error("Get My Bookings Error:", err);
        return sendError(res, "Failed to fetch bookings");
    }
};

// GET BOOKING BY ID
export const getBookingById = async (req, res) => {
    try {
        const userId = req.user.auth_id;
        const { booking_id } = req.params;

        const cacheKey = `booking:${userId}:${booking_id}`;

        const cached = await get(cacheKey);
        if (cached) {
            return sendResponse({
                res,
                message: "Booking fetched successfully",
                data: JSON.parse(cached),
            });
        }

        // User can only view their own booking
        const booking = await Booking.findOne({
            _id: booking_id,
            userId,
        })
            .select("-__v")
            .lean();

        if (!booking) {
            return sendError(
                res,
                "Booking not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        await set(
            cacheKey,
            JSON.stringify(booking),
            "EX",
            DETAIL_CACHE_TTL
        );

        return sendResponse({
            res,
            message: "Booking fetched successfully",
            data: booking,
        });
    } catch (err) {
        console.error("Get Booking By ID Error:", err);
        return sendError(res, "Failed to fetch booking");
    }
};

// CANCEL BOOKING
export const cancelBooking = async (req, res) => {
    try {
        const userId = req.user.auth_id;
        const { booking_id } = req.params;
        const { reason } = req.body;

        const booking = await Booking.findOne({
            _id: booking_id,
            userId,
        }).select("status");

        if (!booking) {
            return sendError(
                res,
                "Booking not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        if (!CANCELLABLE_STATUSES.includes(booking.status)) {
            return sendError(
                res,
                `Booking cannot be cancelled in "${booking.status}" status`,
                STATUS_CODES.CONFLICT
            );
        }

        // Update booking
        booking.status = BOOKING_STATUS.CANCELLED;
        booking.cancellation = {
            reason,
            cancelledBy: "user",
            cancelledAt: new Date(),
        };
        booking.timeline.push({
            status: BOOKING_STATUS.CANCELLED,
            note: `Cancelled by user: ${reason}`,
            timestamp: new Date(),
        });

        await booking.save();

        // Invalidate cache
        await invalidateBookingCache(userId, booking_id);

        // Notify relevant parties (non-blocking)
        addJobToQueue(
            "booking-cancelled",
            {
                name: "BOOKING_CANCELLED",
                data: {
                    bookingId: booking_id,
                    userId,
                    reason,
                },
            },
            { removeOnComplete: true }
        ).catch((err) =>
            console.error("Failed to queue cancellation job:", err)
        );

        return sendResponse({
            res,
            message: "Booking cancelled successfully",
        });
    } catch (err) {
        console.error("Cancel Booking Error:", err);
        return sendError(res, "Failed to cancel booking");
    }
};

// REQUEST RETURN
export const requestReturn = async (req, res) => {
    try {
        const userId = req.user.auth_id;
        const { booking_id } = req.params;
        const { returnLocation, returnScheduledAt, notes } = req.body;

        const booking = await Booking.findOne({
            _id: booking_id,
            userId,
        }).select("status");

        if (!booking) {
            return sendError(
                res,
                "Booking not found",
                STATUS_CODES.NOT_FOUND
            );
        }

        if (!RETURN_REQUESTABLE_STATUSES.includes(booking.status)) {
            return sendError(
                res,
                `Return cannot be requested in "${booking.status}" status`,
                STATUS_CODES.CONFLICT
            );
        }

        // Validate return time
        const returnTime = new Date(returnScheduledAt);
        const minReturnTime = new Date(Date.now() + 60 * 60 * 1000); // At least 1 hour from now

        if (returnTime < minReturnTime) {
            return sendError(
                res,
                "Return must be scheduled at least 1 hour from now",
                STATUS_CODES.BAD_REQUEST
            );
        }

        // Update booking
        booking.status = BOOKING_STATUS.RETURN_REQUESTED;
        booking.returnLocation = {
            type: "Point",
            coordinates: [returnLocation.lng, returnLocation.lat],
            address: returnLocation.address || "",
        };
        booking.return = {
            scheduledAt: returnTime,
            requestedAt: new Date(),
            notes: notes || "",
        };
        booking.timeline.push({
            status: BOOKING_STATUS.RETURN_REQUESTED,
            note: "Return requested by user",
            timestamp: new Date(),
        });

        await booking.save();

        // Invalidate cache
        await invalidateBookingCache(userId, booking_id);

        // Queue return processing
        addJobToQueue(
            "return-process",
            {
                name: "PROCESS_RETURN",
                data: { bookingId: booking_id },
            },
            {
                jobId: `return-${booking_id}`,
                removeOnComplete: true,
                attempts: 3,
                backoff: { type: "exponential", delay: 5000 },
            }
        ).catch((err) =>
            console.error("Failed to queue return job:", err)
        );

        return sendResponse({
            res,
            message: "Return requested successfully",
            data: {
                bookingId: booking._id,
                status: booking.status,
                returnScheduledAt: returnTime,
            },
        });
    } catch (err) {
        console.error("Request Return Error:", err);
        return sendError(res, "Failed to request return");
    }
};