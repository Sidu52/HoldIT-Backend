export const initializeWorkers = async () => {
  await import("./deleteUnverifiedUserWorker.js");
  await import("./driverAssignWorker.js");
  await import("./storeAssignWorker.js");

  console.log("✅ Workers initialized");
};
