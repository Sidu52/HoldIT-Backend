// services/redisService.js

import Redis from "ioredis";
import dotenv from "dotenv";
dotenv.config();

// ============================================
// CONFIGURATION & VALIDATION
// ============================================
if (!process.env.REDIS_HOST || !process.env.REDIS_PORT) {
    console.error("REDIS_HOST and REDIS_PORT must be defined in .env");
    process.exit(1);
}

export const redisConnectionConfig = {
    host: process.env.REDIS_HOST,
    port: Number(process.env.REDIS_PORT),
    username: process.env.REDIS_USERNAME || undefined,
    password: process.env.REDIS_PASSWORD || undefined,
    maxRetriesPerRequest: null,
};

// ============================================
// REDIS CLIENT
// ============================================
const redis = new Redis({
    ...redisConnectionConfig,
    retryStrategy(times) {
        if (times > 10) {
            console.error("Redis: Max reconnection attempts reached");
            return null;
        }
        return Math.min(times * 200, 5000);
    },
    connectTimeout: 10000,
    lazyConnect: true,
});

// ============================================
// EVENTS
// ============================================
redis.on("connect", () => console.log("Redis connected"));
redis.on("ready", () => console.log("Redis ready"));
redis.on("error", (err) => console.error("Redis Error:", err.message));
redis.on("reconnecting", () => console.log("Redis reconnecting"));

// ============================================
// INITIALIZATION
// ============================================
export const initRedis = async () => {
    try {
        await redis.connect();
        await redis.ping();
        console.log("Redis connection verified");
    } catch (err) {
        console.error("Redis initialization failed:", err.message);
        process.exit(1);
    }
};

// ============================================
// BASIC OPERATIONS
// ============================================
export const set = async (key, value, type, expiration) => {
    if (!key || value === undefined || value === null) {
        throw new Error("Redis SET: key and value are required");
    }
    if (type && expiration) {
        return redis.set(key, value, type, expiration);
    }
    return redis.set(key, value);
};

export const get = async (key) => {
    if (!key) throw new Error("Redis GET: key is required");
    return redis.get(key);
};

export const del = async (key) => {
    if (!key) throw new Error("Redis DEL: key is required");
    return redis.del(key);
};

export const exists = async (key) => {
    if (!key) throw new Error("Redis EXISTS: key is required");
    return redis.exists(key);
};

export const ttl = async (key) => {
    if (!key) throw new Error("Redis TTL: key is required");
    return redis.ttl(key);
};

// ============================================
// PATTERN-BASED OPERATIONS (NEW)
// ============================================

/**
 * Scan for keys matching a pattern
 * Uses SCAN (non-blocking) instead of KEYS (blocking)
 * @param {string} pattern - Redis glob pattern (e.g., "refresh:userId:*")
 * @returns {Promise<{keys: string[]}>}
 */
export const scanKeys = async (pattern) => {
    if (!pattern) throw new Error("Redis SCAN: pattern is required");

    const keys = [];
    let cursor = "0";

    do {
        const [nextCursor, foundKeys] = await redis.scan(
            cursor,
            "MATCH",
            pattern,
            "COUNT",
            100
        );
        cursor = nextCursor;
        keys.push(...foundKeys);
    } while (cursor !== "0");

    return { keys };
};

/**
 * Delete all keys matching a pattern
 * @param {string} pattern - Redis glob pattern
 * @returns {Promise<number>} - Number of keys deleted
 */
export const delByPattern = async (pattern) => {
    if (!pattern) throw new Error("Redis DEL_PATTERN: pattern is required");

    const { keys } = await scanKeys(pattern);

    if (keys.length === 0) return 0;

    // Delete in batches to avoid blocking
    const BATCH_SIZE = 100;
    let deleted = 0;

    for (let i = 0; i < keys.length; i += BATCH_SIZE) {
        const batch = keys.slice(i, i + BATCH_SIZE);
        const result = await redis.del(...batch);
        deleted += result;
    }

    return deleted;
};

// ============================================
// SAFETY
// ============================================
export const flushall = async () => {
    if (process.env.NODE_ENV === "production") {
        throw new Error("flushall is disabled in production");
    }
    return redis.flushall();
};

// ============================================
// DEFAULT EXPORT
// ============================================
export default redis;