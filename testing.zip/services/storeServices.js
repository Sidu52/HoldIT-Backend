import redis from "./redisService.js";

export const addStoreToRedis = async (store) => {
    if (!store) {
        console.warn("addStoreToRedis: store is null/undefined");
        return false;
    }

    if (!store.is_active || !store.is_online) {
        if (store._id) {
            await removeStoreFromRedis(store._id, store.service_area_id);
        }
        return false;
    }

    if (
        !store.location ||
        !store.location.coordinates ||
        store.location.coordinates.length < 2
    ) {
        console.warn(`addStoreToRedis: Store ${store._id} has no valid coordinates`);
        return false;
    }

    const [lng, lat] = store.location.coordinates;

    if (
        typeof lng !== "number" || typeof lat !== "number" ||
        lng < -180 || lng > 180 ||
        lat < -90 || lat > 90
    ) {
        console.warn(`addStoreToRedis: Store ${store._id} has invalid coordinates`);
        return false;
    }

    const geoKey = store.service_area_id
        ? `stores:${store.service_area_id}`
        : "stores:global";

    try {
        await redis.geoadd(geoKey, lng, lat, store._id.toString());
        await redis.hset(`store:meta:${store._id}`, {
            is_online: "true",
            booking_assigned_count: (store.booking_assigned_count || 0).toString(),
            max_booking_capacity: (store.max_booking_capacity || 50).toString(),
            service_area_id: store.service_area_id?.toString() || "",
            rating: (store.rating || 0).toString(),
            updated_at: Date.now().toString(),
        });

        return true;
    } catch (err) {
        console.error(`addStoreToRedis error for store ${store._id}:`, err.message);
        return false;
    }
};

export const removeStoreFromRedis = async (storeId, serviceAreaId = null) => {
    if (!storeId) {
        console.warn("removeStoreFromRedis: storeId is null/undefined");
        return false;
    }

    const storeIdStr = storeId.toString();

    try {
        if (serviceAreaId) {
            await redis.zrem(`stores:${serviceAreaId}`, storeIdStr);
        } else {
            const meta = await redis.hget(`store:meta:${storeIdStr}`, "service_area_id");
            if (meta) {
                await redis.zrem(`stores:${meta}`, storeIdStr);
            }
            await redis.zrem("stores:global", storeIdStr);
        }
        await redis.del(`store:meta:${storeIdStr}`);
        return true;
    } catch (err) {
        console.error(`removeStoreFromRedis error for store ${storeId}:`, err.message);
        return false;
    }
};

export const findNearbyStores = async (serviceAreaId, lng, lat, radiusKm = 5, count = 10) => {
    if (!serviceAreaId || lng === undefined || lat === undefined) {
        throw new Error("serviceAreaId, lng, and lat are required");
    }

    const geoKey = `stores:${serviceAreaId}`;

    try {
        const results = await redis.georadius(
            geoKey,
            lng,
            lat,
            radiusKm,
            "km",
            "WITHCOORD",
            "WITHDIST",
            "ASC",
            "COUNT",
            count
        );

        const stores = [];
        for (const [storeId, distance, coords] of results) {
            const meta = await redis.hgetall(`store:meta:${storeId}`);
            const assignedCount = parseInt(meta?.booking_assigned_count || "0", 10);
            const maxCapacity = parseInt(meta?.max_booking_capacity || "50", 10);

            if (assignedCount < maxCapacity) {
                stores.push({
                    storeId,
                    distanceKm: parseFloat(distance),
                    coordinates: {
                        lng: parseFloat(coords[0]),
                        lat: parseFloat(coords[1]),
                    },
                    assignedCount,
                    maxCapacity,
                    rating: parseFloat(meta?.rating || "0"),
                });
            }
        }

        return stores;
    } catch (err) {
        console.error("findNearbyStores error:", err.message);
        return [];
    }
};