import { Queue } from "bullmq";
// BUG FIX 1: Removed `import redis` — using connection config instead
// to avoid shared connection issues (same as queues.js fix)

const redisConnectionConfig = {
    host: process.env.REDIS_HOST,
    port: Number(process.env.REDIS_PORT),
    username: process.env.REDIS_USERNAME || undefined,
    password: process.env.REDIS_PASSWORD || undefined,
    maxRetriesPerRequest: null,
};

const queues = new Map();

// Get or create a BullMQ queue
export const getQueue = (queueName) => {
    // BUG FIX 2: Added input validation
    if (!queueName || typeof queueName !== "string") {
        throw new Error("Queue name must be a non-empty string");
    }

    if (!queues.has(queueName)) {
        queues.set(
            queueName,
            new Queue(queueName, {
                connection: redisConnectionConfig,
                // BUG FIX 3: Changed from `redis` (shared instance) to config object
                defaultJobOptions: {
                    attempts: 3,
                    backoff: {
                        type: "exponential",
                        delay: 3000,
                    },
                    removeOnComplete: {
                        age: 24 * 3600,
                        count: 1000,
                    },
                    removeOnFail: false,
                },
            })
        );
    }
    return queues.get(queueName);
};

export const addJobToQueue = async (queueName, jobNameOrConfig, dataOrOptions = {}, options = {}) => {
    const queue = getQueue(queueName);

    let jobName, data, jobOptions;

    if (typeof jobNameOrConfig === "object" && jobNameOrConfig !== null && jobNameOrConfig.name) {
        jobName = jobNameOrConfig.name;
        data = jobNameOrConfig.data || {};
        jobOptions = dataOrOptions;
    } else {
        jobName = jobNameOrConfig;
        data = dataOrOptions;
        jobOptions = options;
    }

    // BUG FIX 5: Added validation
    if (!jobName || typeof jobName !== "string") {
        throw new Error("Job name must be a non-empty string");
    }

    return queue.add(jobName, data, jobOptions);
};

// Cancel a job by ID
export const cancelJob = async (queueName, jobId) => {
    if (!queueName || !jobId) {
        console.warn("cancelJob: missing queueName or jobId");
        return false;
    }

    const queue = getQueue(queueName);

    try {
        const job = await queue.getJob(jobId);

        if (!job) {
            return false;
        }

        const state = await job.getState();

        if (state === "completed" || state === "failed") {
            await job.remove();
            return true;
        }

        if (state === "active") {
            console.warn(`cancelJob: Job ${jobId} is active, cannot cancel`);
            return false;
        }

        await job.remove();
        return true;
    } catch (err) {
        console.error(`cancelJob error for ${queueName}/${jobId}:`, err.message);
        return false;
    }
};

// Added cleanup function for graceful shutdown
export const closeAllDynamicQueues = async () => {
    const closePromises = [];
    for (const [name, queue] of queues) {
        closePromises.push(
            queue.close().catch((err) => {
                console.error(`Error closing queue ${name}:`, err.message);
            })
        );
    }
    await Promise.allSettled(closePromises);
    queues.clear();
    console.log("All dynamic queues closed");
};