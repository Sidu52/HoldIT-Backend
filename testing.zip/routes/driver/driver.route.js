import express from "express";
import { apiLimiter } from "../../config/rateLimiter.js";
import { updateDriverLocation, updateDriverStatus } from "../../controllers/driver/driver.controller.js";
import { authMiddleware } from "../../middlewares/auth.middleware.js";

const router = express.Router();

router.get("/health", (req, res) => res.json({ message: "OK" }));

// Protected
router.use(authMiddleware);

router.post("/update-driver-location", apiLimiter, updateDriverLocation);
router.post("/update-driver-status", apiLimiter, updateDriverStatus);

export default router;
