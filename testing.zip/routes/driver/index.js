import driverRoute from "./driver.route.js";
import driverAuthRoute from "./auth.driver.route.js";

const driverRoutes = (app) => {
    app.use("/api/v1/driver", driverRoute);
    app.use("/api/v1/driver/auth", driverAuthRoute);
}

export default driverRoutes;