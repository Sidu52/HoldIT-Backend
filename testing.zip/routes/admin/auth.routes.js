import express from "express";
import { apiLimiter } from "../../config/rateLimiter.js";
import { validate } from "../../middlewares/validate.middleware.js";
import {
    adminLogin,
    signUp,
    adminLogout,
    resetPassword,
    verifyAdminInviteToken,
    createAdminForgotPasswordToken,
    updateAdminPassword,
    verifyAdminForgotPasswordToken,
    verifyAuth,
} from "../../controllers/admin/auth.admin.controller.js";
import {
    forgotPasswordSchema,
    loginSchema,
    resetPasswordSchema,
    signupSchema,
    updatePasswordSchema,
    tokenQuerySchema,
} from "../../validations/admin/auth.validation.js";
import { authMiddleware } from "../../middlewares/auth.middleware.js";
import { refresh } from "../../controllers/common/auth.common.controller.js";
import { USER_ROLES } from "../../utils/constants.js";

const router = express.Router();

// ============================================
// PUBLIC ROUTES (No auth required)
// ============================================

// Login
router.post(
    "/login",
    apiLimiter,
    validate(loginSchema),
    adminLogin
);

// Signup via invite
router.post(
    "/signup",
    apiLimiter,
    validate(signupSchema),
    signUp
);

// Verify invite token
router.get(
    "/verify-invite",
    apiLimiter,
    validate(tokenQuerySchema, "query"),
    verifyAdminInviteToken
);

// Refresh access token
router.post(
    "/refresh",
    apiLimiter,
    (req, res) => refresh(req, res, USER_ROLES.ADMIN)
);

// ============================================
// FORGOT PASSWORD FLOW (Public)
// ============================================

// Step 1: Request password reset email
router.post(
    "/forgot-password",
    apiLimiter,
    validate(forgotPasswordSchema),
    createAdminForgotPasswordToken
);

// Step 2: Verify reset token (from email link)
router.get(
    "/verify-reset-token",
    apiLimiter,
    validate(tokenQuerySchema, "query"),
    verifyAdminForgotPasswordToken
);

// Step 3: Set new password with reset token
router.post(
    "/forgot-password/reset",
    apiLimiter,
    validate(resetPasswordSchema),
    updateAdminPassword
);

// ============================================
// PROTECTED ROUTES (Auth required)
// ============================================
router.use(authMiddleware);

// Verify current session
router.get(
    "/verify",
    verifyAuth
);

// Logout
router.post(
    "/logout",
    apiLimiter,
    adminLogout
);

// Change password
router.put(
    "/change-password",
    apiLimiter,
    validate(updatePasswordSchema),
    resetPassword
);

export default router;