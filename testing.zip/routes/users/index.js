import userAuthRoute from "./auth.user.js";
import userRoute from "./user.user.js";
import bookingRoute from "./booking.user.js";
import storesRoute from "./store.user.routes.js";

const userRoutes = (app) => {
    app.use("/api/v1/user/auth", userAuthRoute);
    app.use("/api/v1/user", userRoute);
    app.use("/api/v1/user/booking", bookingRoute);
    app.use("/api/v1/user/stores", storesRoute);
}

export default userRoutes;