import express from "express";
import { apiLimiter } from "../../config/rateLimiter.js";
import { authMiddleware } from "../../middlewares/auth.middleware.js";
import { validate } from "../../middlewares/validate.middleware.js";
import {
    schedulePickup,
    getMyBookings,
    getBookingById,
    cancelBooking,
    requestReturn,
} from "../../controllers/user/booking.user.controller.js";
import {
    schedulePickupSchema,
    bookingIdSchema,
    cancelBookingSchema,
    requestReturnSchema,
    listBookingsSchema,
} from "../../validations/user/booking.user.validation.js";

const router = express.Router();

// Routes require authentication
router.use(authMiddleware);

// ------------------ BOOKING ROUTES -------------
// Schedule a pickup
router.post(
    "/pickup",
    apiLimiter,
    validate(schedulePickupSchema),
    schedulePickup
);

// Get my bookings (paginated)
router.get(
    "/",
    apiLimiter,
    validate(listBookingsSchema, "query"),
    getMyBookings
);

// Get single booking
router.get(
    "/:booking_id",
    apiLimiter,
    validate(bookingIdSchema, "params"),
    getBookingById
);

// Cancel a booking
router.post(
    "/:booking_id/cancel",
    apiLimiter,
    validate(bookingIdSchema, "params"),
    validate(cancelBookingSchema),
    cancelBooking
);

// Request return of luggage
router.post(
    "/:booking_id/return",
    apiLimiter,
    validate(bookingIdSchema, "params"),
    validate(requestReturnSchema),
    requestReturn
);

export default router;