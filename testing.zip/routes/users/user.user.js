import express from "express";
import { apiLimiter } from "../../config/rateLimiter.js";
import { authMiddleware } from "../../middlewares/auth.middleware.js";
import { validate } from "../../middlewares/validate.middleware.js";
import {
    getProfile,
    updateProfile,
    getNearestStore,
    getStoreById,
} from "../../controllers/user/user.user.controller.js";
import {
    nearestStoreSchema,
    updateProfileSchema,
    storeIdSchema,
} from "../../validations/user/user.profile.validation.js";

const router = express.Router();

router.use(authMiddleware);


// Get profile
router.get(
    "/profile",
    apiLimiter,
    getProfile
);

// Update profile
router.put(
    "/profile",
    apiLimiter,
    validate(updateProfileSchema),
    updateProfile
);


// Find nearest store
router.get(
    "/stores/nearest",
    apiLimiter,
    validate(nearestStoreSchema, "query"),
    getNearestStore
);

// Get store details
router.get(
    "/stores/:store_id",
    apiLimiter,
    validate(storeIdSchema, "params"),
    getStoreById
);

export default router;