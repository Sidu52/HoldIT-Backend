import express from "express";
import {
    searchStores,
    getNearbyStores,
    getStoreById,
} from "../../controllers/user/search.user.controller.js";
import { apiLimiter } from "../../config/rateLimiter.js";
import { authMiddleware } from "../../middlewares/auth.middleware.js";
import { validate } from "../../middlewares/validate.middleware.js";
import {
    searchStoresSchema,
    nearbyStoresSchema,
    storeIdSchema,
} from "../../validations/user/store.validator.js";

const router = express.Router();

router.get(
    "/search",
    apiLimiter,
    authMiddleware,
    validate(searchStoresSchema, "query"),
    searchStores
);

router.get(
    "/nearby",
    apiLimiter,
    authMiddleware,
    validate(nearbyStoresSchema, "query"),
    getNearbyStores
);

router.get(
    "/:id",
    apiLimiter,
    authMiddleware,
    validate(storeIdSchema, "params"),
    getStoreById
);

export default router;