import Joi from "joi";

// Search stores validation schema
export const searchStoresSchema = Joi.object({
    q: Joi.string()
        .trim()
        .min(2)
        .max(100)
        .optional()
        .messages({
            "string.min": "Search query must be at least 2 characters",
            "string.max": "Search query must not exceed 100 characters",
        }),

    lat: Joi.number()
        .min(-90)
        .max(90)
        .optional()
        .messages({
            "number.min": "Latitude must be between -90 and 90",
            "number.max": "Latitude must be between -90 and 90",
        }),

    lng: Joi.number()
        .min(-180)
        .max(180)
        .optional()
        .messages({
            "number.min": "Longitude must be between -180 and 180",
            "number.max": "Longitude must be between -180 and 180",
        }),

    radius: Joi.number()
        .integer()
        .min(100)
        .max(50000)
        .default(5000)
        .optional()
        .messages({
            "number.min": "Radius must be at least 100 meters",
            "number.max": "Radius must not exceed 50,000 meters (50 km)",
        }),

    sort: Joi.string()
        .valid("distance", "rating", "newest")
        .default("distance")
        .optional(),

    open_now: Joi.string()
        .valid("true", "false")
        .optional(),

    limit: Joi.number()
        .integer()
        .min(1)
        .max(50)
        .default(20)
        .optional(),

    page: Joi.number()
        .integer()
        .min(1)
        .max(100)
        .default(1)
        .optional(),
})
    .custom((value, helpers) => {
        const hasQuery = value.q && value.q.trim().length >= 2;
        const hasCoords =
            value.lat !== undefined && value.lng !== undefined;

        if (!hasQuery && !hasCoords) {
            return helpers.error("any.custom", {
                message:
                    "Please provide a search query or location coordinates (lat & lng)",
            });
        }

        // If one coordinate provided, both must be present
        if (
            (value.lat !== undefined && value.lng === undefined) ||
            (value.lat === undefined && value.lng !== undefined)
        ) {
            return helpers.error("any.custom", {
                message: "Both latitude and longitude are required together",
            });
        }

        return value;
    })
    .messages({
        "any.custom": "{{#message}}",
    });

// Nearby stores validation schema
export const nearbyStoresSchema = Joi.object({
    lat: Joi.number()
        .min(-90)
        .max(90)
        .required()
        .messages({
            "any.required": "Latitude is required for nearby search",
            "number.min": "Latitude must be between -90 and 90",
            "number.max": "Latitude must be between -90 and 90",
        }),

    lng: Joi.number()
        .min(-180)
        .max(180)
        .required()
        .messages({
            "any.required": "Longitude is required for nearby search",
            "number.min": "Longitude must be between -180 and 180",
            "number.max": "Longitude must be between -180 and 180",
        }),

    radius: Joi.number()
        .integer()
        .min(100)
        .max(50000)
        .default(5000)
        .optional(),

    open_now: Joi.string()
        .valid("true", "false")
        .optional(),

    limit: Joi.number()
        .integer()
        .min(1)
        .max(50)
        .default(20)
        .optional(),

    page: Joi.number()
        .integer()
        .min(1)
        .max(100)
        .default(1)
        .optional(),
});
// Store ID validation schema
export const storeIdSchema = Joi.object({
    id: Joi.string()
        .pattern(/^[0-9a-fA-F]{24}$/)
        .required()
        .messages({
            "string.pattern.base": "Invalid store ID format",
            "any.required": "Store ID is required",
        }),
});