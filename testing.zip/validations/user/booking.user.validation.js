import Joi from "joi";

// LOCATION SUB-SCHEMA
const locationSchema = Joi.object({
    lat: Joi.number().min(-90).max(90).required().messages({
        "number.base": "Latitude must be a number",
        "number.min": "Latitude must be between -90 and 90",
        "number.max": "Latitude must be between -90 and 90",
        "any.required": "Latitude is required",
    }),
    lng: Joi.number().min(-180).max(180).required().messages({
        "number.base": "Longitude must be a number",
        "number.min": "Longitude must be between -180 and 180",
        "number.max": "Longitude must be between -180 and 180",
        "any.required": "Longitude is required",
    }),
    address: Joi.string().trim().max(255).optional(),
});

// LUGGAGE SUB-SCHEMA
const luggageSchema = Joi.object({
    small: Joi.number().integer().min(0).max(20).default(0),
    medium: Joi.number().integer().min(0).max(20).default(0),
    large: Joi.number().integer().min(0).max(10).default(0),
    other: Joi.number().integer().min(0).max(5).default(0),
})
    .required()
    .custom((value, helpers) => {
        const total =
            (value.small || 0) +
            (value.medium || 0) +
            (value.large || 0) +
            (value.other || 0);

        if (total <= 0) {
            return helpers.error("luggage.minimum");
        }

        if (total > 30) {
            return helpers.error("luggage.maximum");
        }

        return value;
    })
    .messages({
        "luggage.minimum": "At least one luggage item is required",
        "luggage.maximum": "Total luggage cannot exceed 30 items",
        "any.required": "Luggage details are required",
    });

// SCHEDULE PICKUP
export const schedulePickupSchema = Joi.object({
    pickupLocation: locationSchema.required().messages({
        "any.required": "Pickup location is required",
    }),
    pickupScheduledAt: Joi.date()
        .iso()
        .min("now")
        .required()
        .messages({
            "date.base": "Invalid pickup date",
            "date.min": "Pickup time must be in the future",
            "any.required": "Pickup scheduled time is required",
        }),
    luggage: luggageSchema,
    notes: Joi.string().trim().max(500).allow("").optional(),
});

// BOOKING ID PARAM
export const bookingIdSchema = Joi.object({
    booking_id: Joi.string()
        .pattern(/^[0-9a-fA-F]{24}$/)
        .required()
        .messages({
            "string.pattern.base": "Invalid booking ID format",
            "any.required": "Booking ID is required",
        }),
});

// CANCEL BOOKING
export const cancelBookingSchema = Joi.object({
    reason: Joi.string().trim().min(5).max(500).required().messages({
        "any.required": "Cancellation reason is required",
        "string.min": "Reason must be at least 5 characters",
    }),
});

// REQUEST RETURN
export const requestReturnSchema = Joi.object({
    returnLocation: locationSchema.required().messages({
        "any.required": "Return location is required",
    }),
    returnScheduledAt: Joi.date()
        .iso()
        .min("now")
        .required()
        .messages({
            "date.base": "Invalid return date",
            "date.min": "Return time must be in the future",
            "any.required": "Return scheduled time is required",
        }),
    notes: Joi.string().trim().max(500).allow("").optional(),
});

// LIST BOOKINGS QUERY
export const listBookingsSchema = Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(50).default(10),
    status: Joi.string()
        .valid(
            "created",
            "store_assigned",
            "driver_assigned",
            "picked_up",
            "stored",
            "return_requested",
            "out_for_return",
            "delivered",
            "cancelled"
        )
        .optional(),
    sort_order: Joi.string().valid("asc", "desc").default("desc"),
});