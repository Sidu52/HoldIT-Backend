// STATUS CODES
const STATUS_CODES = {
  SUCCESS: 200,
  CREATED: 201,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500,
};

// USER & ROLE MANAGEMENT
const USER_ROLES = {
  ADMIN: "admin",
  SUPER_ADMIN: "super_admin",
  OPERATION_MANAGER: "operation_manager",
  CUSTOMER_SUPPORT: "customer_support",
};

const ACCOUNT_STATUS = {
  ACTIVE: "active",
  PENDING: "pending",
  BLOCKED: "blocked",
  INACTIVE: "inactive",
};

const GENDER_OPTIONS = ["male", "female", "other", "prefer_not_to_say"];

// AUTHENTICATION & TOKENS
const TOKEN_TYPES = {
  ACCESS: "access",
  REFRESH: "refresh",
  INVITE: "invite",
};

const ACCESS_TOKEN_EXPIRY = 15;     // 15 minutes (used as `${val}m`)
const REFRESH_TOKEN_EXPIRY = 7;     // 7 days (used as `${val}d`)
const INVITE_TOKEN_EXPIRY = 24;     // 24 hours (used as `${val}h`)

const PASSWORD_MIN_LENGTH = 8;
const PASSWORD_MAX_LENGTH = 100;

// OTP CONFIGURATION
const OTP_LENGTH = 6;
const OTP_EXPIRY = 5;                         // 5 minutes
const OTP_MAX_ATTEMPTS = 5;                   // Max verification attempts per OTP
const OTP_COOLDOWN = 60;                      // Seconds before requesting new OTP
const OTP_MAX_REQUESTS_PER_HOUR = 5;          // Max OTP requests per hour per user

// RATE LIMITING
const RATE_LIMIT = {
  LOGIN_MAX_ATTEMPTS: 5,                      // Per 15-minute window
  LOGIN_WINDOW_MINUTES: 15,
  API_MAX_REQUESTS: 100,                      // General API rate limit
  API_WINDOW_MINUTES: 15,
};

// BOOKING STATUS
const BOOKING_STATUS = {
  CREATED: "created",
  STORE_ASSIGNED: "store_assigned",
  DRIVER_SEARCH: "driver_search",
  DRIVER_ASSIGNED: "driver_assigned",
  DRIVER_ARRIVED: "driver_arrived",
  PICKED_UP: "picked_up",
  STORED: "stored",
  RETURN_REQUESTED: "return_requested",
  OUT_FOR_RETURN: "out_for_return",
  DELIVERED: "delivered",
  CANCELLED: "cancelled",
};

const ASSIGNMENT_TYPES = {
  PICKUP: "PICKUP",
  DELIVERY: "DELIVERY",
  RETURN: "RETURN",
};

// VERIFICATION & ONBOARDING
const VERIFICATION_STATUS = {
  PENDING: "pending",
  VERIFIED: "verified",
  REJECTED: "rejected",
};

const ON_BOARDING_STATUS = {
  DEMO: "demo",
  DOCUMENTS_PENDING: "documents_pending",
  ACTIVE: "active",
};

// VEHICLE
const VEHICLE_TYPES = {
  CAR: "car",
  BIKE: "bike",
  MOTORCYCLE: "motorcycle",
  CYCLE: "cycle",
  SCOOTER: "scooter",
};

export {
  STATUS_CODES,
  USER_ROLES,
  ACCOUNT_STATUS,
  GENDER_OPTIONS,
  TOKEN_TYPES,
  ACCESS_TOKEN_EXPIRY,
  REFRESH_TOKEN_EXPIRY,
  INVITE_TOKEN_EXPIRY,
  PASSWORD_MIN_LENGTH,
  PASSWORD_MAX_LENGTH,
  OTP_LENGTH,
  OTP_EXPIRY,
  OTP_MAX_ATTEMPTS,
  OTP_COOLDOWN,
  OTP_MAX_REQUESTS_PER_HOUR,
  RATE_LIMIT,
  BOOKING_STATUS,
  ASSIGNMENT_TYPES,
  VERIFICATION_STATUS,
  ON_BOARDING_STATUS,
  VEHICLE_TYPES,
};